
const jwtkey = "SHA256FEMSAPP";

export default jwtkey
