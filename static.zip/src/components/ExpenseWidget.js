import { IconButton, Typography } from '@material-ui/core'
import React from 'react'
import { Fragment } from 'react'
import { useSelector } from 'react-redux'
import { selectUserExpenseRaised } from '../appState/appSlice'
import AppWidgetHeader from './global/AppWidgetHeader'

const ExpenselWidget = ({ isWidget, setIswidget }) => {
    const calcuAmt = (data) =>{
        const total = data&& data.reduce((a, v) =>+v.amount+ a, 0)
        return total
    }
    const userExpneses = useSelector(selectUserExpenseRaised)
    return (
        <div className='app__Widget'>
            <AppWidgetHeader
                isWidget={isWidget}
                setIswidget={setIswidget}
                title='Expense List' 
            />
            <section className='app__WidgetContainer mt-3'>
               <table className='table table-sm table-striped table-hover'>
                   <thead>
                       <th style={{ border: '1px solid #F7F7F7F7' }}>#</th>
                       <th style={{ border: '1px solid #F7F7F7F7' }}>Expense</th>
                       <th style={{ border: '1px solid #F7F7F7F7' }}>Amount (<s>N</s>)</th>
                       <th style={{ border: '1px solid #F7F7F7F7' }}>Date</th>
                   </thead>
                   <tbody>
                       {
                           userExpneses&&
                           userExpneses.map((exps, index) =>{
                               const { uuid, amount, expense_date } = exps
                               return (
                                   <tr>
                                       <td> {index+1} </td>
                                       <td> 
                                           <Typography variant='p'
                                            style={{color: '#20C997', cursor: 'pointer'}}
                                           >
                                           {`Expense #${uuid}`}
                                           </Typography>
                                       </td>
                                       <td> {amount} </td>
                                       <td> {new Date(expense_date).toLocaleDateString()} </td>
                                   </tr>
                                   
                               )
                           })
                           
                       }
                       {
                           userExpneses&&
                           <tr
                            style={{background: '#2A3F54', color: 'white'}} 
                           >
                               <td colSpan={2}>
                                   <Typography variant='subtitle1'
                                    style={{color: 'white'}}
                                   >
                                        <b>Total:</b>
                                    </Typography>
                               </td>
                               <td>
                                   <Typography variant='subtitle1'
                                    style={{color: 'white'}}
                                   >
                                    <b>{
                                       calcuAmt(userExpneses)
                                    }</b>
                                   </Typography>
                               </td>
                               <td colSpan={1}></td>
                           </tr>
                       }
                   </tbody>
               </table>
            </section>
        </div>
    )
}

export default ExpenselWidget
