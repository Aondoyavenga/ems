import db from "../../db.js";
import createdAt from "../../middleware/createdAt.js";

const get_All_Sales_Pending = (req, res) => {
  const query = `SELECT * FROM sales_model WHERE status=? AND md_status=?`;
  db.query(query, [0, 0], (error, result) => {
    if (error) return console.error(error.message);
    res.status(200).send(result);
  });
};

const get_All_Sale_Scheldule = (req, res) => {
  const { uuid } = req.params;
  const query = `SELECT * FROM sales_scheldule_model WHERE sale_uuid=?`;
  db.query(query, [uuid], (error, result) => {
    if (error) return console.error(error.message);
    res.status(200).send(result);
  });
};

const get_Payment_History = (req, res) => {
  const { uuid } = req.params;

  const query = `
        SELECT sales_model.uuid, sales_model.amount, sales_model.applicant_name, sales_model.amount_paid, sales_model.applicant, 
        sales_model.due_date, transactionmodel.rcpt_no, transactionmodel.account_FK, transactionmodel.amount AS tx_amount, 
        transactionmodel.pay_method, transactionmodel.description, transactionmodel.tx_date, transactionmodel.paid FROM sales_model
        JOIN transactionmodel ON(transactionmodel.rcpt_no=sales_model.uuid)
        WHERE sales_model.status = 0 AND sales_model.uuid='${uuid}'
    `;
  db.query(query, (error, result) => {
    if (error) return console.error(error.message);
    res.status(200).send(result);
  });
};

const get_All_Paid_On_Pay = (req, res) => {
  const query = `
        SELECT * FROM sales_model  WHERE md_status=? AND(status=? OR status=? OR md_status=?)
    `;
  db.query(query, [1, 0, 1, 1], (error, result) => {
    if (error) return console.error(error.message);
    res.status(200).send(result);
  });
};

const get_All_Sales = (req, res) => {
  const query = `
    SELECT 
    sales_model.id,
    sales_model.uuid,
    sales_model.property,
    sales_model.amount,
    sales_model.amount_paid,
    sales_model.period,
    sales_model.applicant,
    sales_model.applicant_name,
    sales_model.build_category,
    sales_model.sale_date,
    sales_model.due_date,
    sales_model.createdAt,
    sales_model.createdBy_FK,
    sales_items_model.property,
    prop_servicemodel.name AS property_name
    FROM sales_model
    JOIN sales_items_model
    ON sales_model.uuid = sale_ID
    JOIN prop_servicemodel
    ON sales_items_model.property = prop_servicemodel.id
    `;
  db.query(query, (error, result) => {
    if (error) return res.status(404).send(error.message);
    res.status(200).send(result);
  });
};

const get_Sale_Repayment_Report = (req, res) => {
  const { from, to } = req.params;
  const query = `
        SELECT sales_model.applicant_name, sales_model.amount, sales_model.property_name,
        sales_model.amount_paid, sales_model.due_date, transactionmodel.amount AS tx_amount, 
        transactionmodel.rcpt_no, transactionmodel.account_FK, transactionmodel.pay_method, sales_model.status, transactionmodel.tx_date
        FROM sales_model
        JOIN transactionmodel ON( sales_model.uuid = transactionmodel.rcpt_no)
        WHERE transactionmodel.tx_date BETWEEN ? AND ?
    `;

  db.query(query, [from, to], (error, result) => {
    if (error) return res.status(404).send(error.message);
    res.status(200).send(result);
  });
};

const post_Sale_Scheldule = (VALUES) => {
  const query = `INSERT INTO sales_scheldule_model
        (
            sale_uuid, applicant_name,
            amount,  period, date, property_name
        )
        VALUES ?
    `;
  db.query(query, [VALUES], (error, result) => {
    if (error) return console.error(error.message);
    return true;
  });
};

const handleApproval = (req, res) => {
  const { username } = req.user;
  const { id } = req.body;
  //    return console.log(username)
  const query = `UPDATE sales_model SET status=?, md_status =?, md_session=?, md_date=? WHERE id=?`;
  db.query(query, [1, 1, username, createdAt, id], (error, result) => {
    if (error) return console.error(error.message);
    res.status(201).send({ message: "Approved" });
  });
};

const updateProperty = async(data) =>{
    let result =[];
    let error;
    const querProperty = `SELECT id, quantity, name FROM prop_servicemodel`;
    const query =`
        UPDATE prop_servicemodel SET quantity =? WHERE id =?
    `;

   db.query(querProperty, async(err, res) =>{
        if(err){
            
           console.log(err.message);
            return err.message
        }
         
        const property = data.map(item => {
           return res.find(p => p.id == parseInt(item[3] ))
           
        })
        
        for (let i = 0; i < data.length; i++) {
            const element = property[i];
           
            if( element.quantity < parseInt(data[i][0]) ) return console.log({message:  `${element.name} has ${element.quantity} left`})
            db.query(query, [element.quantity - parseInt(data[i][0]), element.id], (error, update) =>{
                if(error) return console.error(error.message);
                console.log(update)
            })
        }
    })
   
}

const handle_Insert_Sale_Item = async (data) => {
  const query = `INSERT INTO sales_items_model (
        qty, amount, sale_ID, property,location,createdAt, building_category
    )
    VALUES ?`;
  db.query(query, [data], (error, result) => {
    if (error) return error.message;
    return result;
  });
};

const create_Sale = (req, res) => {
    const { id } = req.user;
    const {
        uuid,
        total,
        period,
        applicant_name,
        sale_date,
        due_date,
        VALUES,
        applicant,
    } = req.body;

    const querProperty = `SELECT id, quantity, name FROM prop_servicemodel`;
    const updatePropertyQuery =`
        UPDATE prop_servicemodel SET quantity =? WHERE id =?
    `;

    const query = `INSERT INTO sales_model
        (
            uuid, amount, period,
            applicant_name, sale_date, due_date, createdAt, createdBy_FK, applicant
        )
        VALUES(
            '${uuid}', '${total}', 
            '${period}', '${applicant_name}', '${sale_date}', 
            '${due_date}', '${createdAt}', '${id}', '${applicant}'
        )
    `;    
           
    const validate = `SELECT applicant FROM sales_model WHERE applicant =? AND status=?`;

    db.query(querProperty, async(err, resp) =>{
        if(err){
            
           return res.status(501).send(err.message)
        }
         
        const property = VALUES.map(item => {
           return resp.find(p => p.id == parseInt(item[3] ))
           
        })
        
        for (let i = 0; i < VALUES.length; i++) {
            const element = property[i];
           
            if( element.quantity < parseInt(VALUES[i][0]) ) return res
                .status(404).send({message:  `${element.name} has ${element.quantity} quantity left for sale`})

            db.query(updatePropertyQuery, [element.quantity - parseInt(VALUES[i][0]), element.id], (error, update) =>{
                if(error) return res.status(404).send(error.message);
                
                db.query(validate, [applicant, 0], (error, result) => {
                    if (error) return res.status(404).send(error.message);
                    if (result && result.length > 0)
                    return res
                        .status(401)
                        .send({ message: `${applicant_name} purchase still open` });
                        
                    db.query(query, (error, result) => {
                    if (error) return res.status(404).send(error.message);
            
                    return handle_Insert_Sale_Item(VALUES)
                        .then((message) => res.status(201).send({ message: `${uuid} Created` }))
                        .catch((error) => res.status(404).send(error));
                    });
                });

            })
        }
    })

    
};
const SALES = {
  get_All_Sales,
  create_Sale,
  handleApproval,
  get_All_Sales_Pending,
  get_All_Sale_Scheldule,
  get_Payment_History,
  get_All_Paid_On_Pay,
  get_Sale_Repayment_Report,
};

export default SALES;
